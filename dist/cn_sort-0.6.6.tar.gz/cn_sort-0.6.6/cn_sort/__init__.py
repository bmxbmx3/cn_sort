from .decorator import *
from .process_cn_word import *

name="cn_sort"